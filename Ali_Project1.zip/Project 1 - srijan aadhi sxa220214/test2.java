import java.util.Scanner;
import java.util.stream.Stream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.*;
public class test2 {
    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(new File("purchases.txt"));
        String[] line_split = scan.nextLine().split(" ");

        Gold g = new Gold(null, null, null, 0);
       
        System.out.println((line_split[1] == "M"));
    }

    public static void mid(int lol)
    {
        lol += 3;
    }
}
